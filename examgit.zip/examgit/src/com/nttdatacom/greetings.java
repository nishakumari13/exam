package com.nttdatacom;

public class greetings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hello ...greetings example!!");
	}

}
